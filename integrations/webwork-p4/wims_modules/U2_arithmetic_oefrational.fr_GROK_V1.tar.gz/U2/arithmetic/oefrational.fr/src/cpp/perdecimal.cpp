target= perdecimal1 perdecimal2 perdecimal3

\author{Bernadette, Perrin-Riou}
\email{bernadette.m.riou@orange.fr}
\css{<style>
 .reponse {color:navy;margin:2% 5%;padding:2%;text-align:center;}
 </style>}
#if defined TARGET_perdecimal1
\title{Arithm�tique et d�veloppement}
\text{d_n= randint(10..50)}
\text{d = pari(prime(\d_n))}
\text{per=pari(znorder(Mod(10,\d)))}
\while{\per < 22}{
  \integer{d_n = \d_n + 1}
  \text{d = pari(prime(\d_n))}
  \text{per=pari(znorder(Mod(10,\d)))}
}
#endif
#if defined TARGET_perdecimal3
\title{Calculer un d�veloppement}

\text{d_n= randint(10..30)}
\text{d = pari(prime(\d_n))}
\text{per=pari(znorder(Mod(10,\d)))}
\while{\per < 40}{
  \integer{d_n = \d_n + 1}
  \text{d = pari(prime(\d_n))}
  \text{per=pari(znorder(Mod(10,\d)))}
}
#endif
#if defined TARGET_perdecimal2

\title{Arithm�tique et d�veloppement (II)}

\text{d_n= randint(10..13)}
\text{deux= randint(2..5)}
\text{d = pari(prime(\d_n)*prime(\d_n + \deux))}
\text{per=pari(znorder(Mod(10,\d)))}
\integer{test=0}
\while{\test < 5 and \per < 22 }{
  \integer{d_n = \d_n + 1}
  \text{d = pari(prime(\d_n)*prime(\d_n + \deux))}
  \integer{per=pari(znorder(Mod(10,\d)))}
  \integer{test= \test + 1 }
}

\if{\test = 5}{
  \text{d_n= randint(10..13)}
  \text{per=pari(znorder(Mod(10,\d)))}
  \while{\per < 22}{
    \integer{d_n = \d_n + 1}
    \text{d = pari(prime(\d_n))}
    \text{per=pari(znorder(Mod(10,\d)))}
  }
}
#endif
\text{pair="#FFFFFF","#FFFFCC"}
\text{borne = 7}
\text{n = wims(values \borne * x for x = 1 to min(10,\per/\borne))}
\text{s = pari(n=[\n] ; vector(#n,i,lift(Mod(10,\d)^(n[i]))))}

\text{N_liste = pari( s = [\s] ; vector(#s,i,1.*s[i]/\d))}
\text{N = pari(1./\d)}
\text{s_cnt=items(\s)}
\text{u = randint(3..\s_cnt-1)}
\text{r = randint(\n[\u]..\n[\u+1]-4)}
\integer{u = \r = \n[\u] ? \u-1}
\integer{t = \r - \n[\u] + 2}
\text{nombre = \N_liste[\u]}
\text{rep = wims(char \t..\t+2 of \nombre)}

\text{s_ord = wims(sort numeric item \s)}
\text{N_liste_ord = pari( s = [\s_ord] ; vector(#s,i,1.*s[i]/\d))}
\text{tableau =}
\for{i = 1 to \s_cnt}{
\integer{parite=\i%2}
\text{tableau = \s[\i] != 1 ? \tableau
<tr>
<th> \s_ord[\i]/\d</th><td> = </td><td>\N_liste_ord[\i]... </td>
<th>\(10^\n[\i]) </th><td>\(\equiv )</td><td> \s[\i] mod \d </td>
</tr>
}
}
#if defined TARGET_perdecimal1 || defined TARGET_perdecimal2
\statement{
  <div class="wims_question">Calculer la p�riode du d�veloppement d�cimal de
  \(\frac{1}{\d}) : \embed{reply1,5}</div>
  Le d�but du d�veloppement limit� du nombre rationnel
  \(\frac{1}{\d}) est
  <div class="wimscenter"> \( x = \N... ) </div>
  <div class="wims_instruction">Attention: le dernier chiffre est peut-�tre faux.</div>

  <div class="wims_question">A partir des renseignements suivants, calculer
    les trois chiffres cons�cutifs de son d�veloppement d�cimal
    � partir du <b>\r</b>-i�me chiffre apr�s la virgule :
  <div class="wimscenter"> \embed{reply2,5} </div>
  </div>
  <table class="wimscenter wimsnoborder">
  \tableau
  </table>

  <div class="wims_instruction">On �crira les chiffres sans espace entre eux.</div>
}
\answer{p�riode}{\per}
\answer{\r-i�me chiffre et deux suivants}{\rep}{type=nocase}

#endif
#if defined TARGET_perdecimal3
\text{H=randint(16..18)}
\integer{H2 = 2*\H}
\text{N1 = wims(char 1 to \H+2 of \N)}
\text{rep = pari( s = [\s] ; [1.*lift(Mod(10,\d)^\H)/\d, 1.*lift(Mod(10,\d)^(2*\H))/\d])}
\text{rep = wims(char 3 to \H+2 of \rep[1])wims(char 3 to \H+2 of \rep[2])}

\statement{
  Le d�but du d�veloppement limit� du nombre rationnel
  \(\frac{1}{\d}) est
  <div class="wimscenter"> \( x = \N... ) </div>
  <div class="wims_instruction">Attention: le dernier chiffre est peut-�tre faux.</div>

  <div class="wims_question">A partir des renseignements suivants, calculer
  les \H2 chiffres suivants de son d�veloppement d�cimal
  <div class="wimscenter"> \( x ) = \N1 \embed{reply1,\H2} </div>
  </div>
  <table class="wimscenter">
  \tableau
  </table>
}

\answer{}{\reponse}
\text{distance= wims(text compare \rep and \reply1)}
\integer{dist=0}
\text{correction=}
\text{cnt = wims(charcnt \distance)}
\for{i = 1 to \cnt}{
  \text{u=wims(char \i of \distance)}
  \text{couleur = \u=1 ? oef_indbad: oef_indgood}
  \integer{dist=\dist + \u}
  \text{correction= \correction<span class="\couleur">wims(char \i of \rep)</span>}
}

\condition{}{\rep = \reply1}{weight=10}{option=hide}
\condition{Au plus 5 chiffres faux}{\dist < 5 }{weight = 10}{option=hide}
\condition{Au plus 10 chiffres faux}{\dist < 10 }{weight = 10}{option=hide}
\feedback{1=1}{
<div class="reponse">La bonne r�ponse est
<div class="wimscenter"> \( x ) = \N1 \correction.</div>
</div>
}

#endif
\help{ Voir par exemple
<a target="wims_external" href="wims.cgi?module=U3/algo/doceuclide.fr">Autour de l'algorithme d'Euclide</a>
}
